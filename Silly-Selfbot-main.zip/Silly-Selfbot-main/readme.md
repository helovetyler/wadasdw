# Silly Selfbot
> *Best free open source discord raiding selfbot*

# Setup

Read the install guide.md for help

# Regards

Good luck
