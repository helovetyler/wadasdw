

██╗███╗   ██╗███████╗████████╗ █████╗ ██╗     ██╗          ██████╗ ██╗   ██╗██╗██████╗ ███████╗
██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██║     ██║         ██╔════╝ ██║   ██║██║██╔══██╗██╔════╝
██║██╔██╗ ██║███████╗   ██║   ███████║██║     ██║         ██║  ███╗██║   ██║██║██║  ██║█████╗  
██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║     ██║         ██║   ██║██║   ██║██║██║  ██║██╔══╝  
██║██║ ╚████║███████║   ██║   ██║  ██║███████╗███████╗    ╚██████╔╝╚██████╔╝██║██████╔╝███████╗
╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚══════╝     ╚═════╝  ╚═════╝ ╚═╝╚═════╝ ╚══════╝

<- How to install silly selfbot ->

1. Make sure to have Python 3.11.5 if you have errors since I use this version and it works fine, some later versions mess with discord.py (the wrapper I use)

╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║▓░░░░░░▓ [ INSTALL ] ▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▓ [ SILLY  ] ▓░░░░▓║
╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝

1. Install this github repository by clicking *Code* then *Download ZIP*
2. Extract the zip file you just downloaded to a folder
3. Run the *install.bat* file to install all requirements needed for this
4. Run the *open.bat* file to execute the script

╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║▓░░░░░░▓ [ SETUP ] ▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▓ [ SILLY  ] ▓░░░░▓║
╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝

1. The token it asks for is your discord account token google *How to get account token*
2. The prefix is the symbol you will put before your commands to make then run
3. IP lookup key is an api for looking up ip adddresses
4. The sniper options can be answered with Y/N
5. Encrypt token will make the token in *config.json* to make sure people can not steal ur token from the config
6. The password is used to decrypt your token (only needed if Encrypt token is allowed)
7. GUI allows for a web based UI
8. Afk message is the message used when you are afk

╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║▓░░░░░░▓ [ REGARDS ] ▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▓ [ SILLY  ] ▓░░░░▓║
╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝

We here are the Silly Selfbot project wish you happy raiding with the best free raiding selfbot ever...
