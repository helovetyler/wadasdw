@bot.command()
async def axe(ctx):
    axe = """
  ,  /\  .  
 //`-||-'\\ 
(| -=||=- |)
 \\,-||-.// 
  `  ||  '  
     ||     
     ||     
     ||     
     ||     
     ||     
     ()
""" 
    await ctx.send(axe)