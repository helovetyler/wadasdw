@bot.command()
async def penis(ctx):
    await ctx.send("Penis")